#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT to your Android SDK}"
BT="$ANDROID_SDK_ROOT/build-tools/35.0.0"
ANDROID_JAR="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
mkdir -p build/{compiled,generated,classes,dex}
"$BT/aapt2" compile --dir app/src/main/res -o build/compiled/resources.zip
"$BT/aapt2" link -o build/unsigned.apk -I "$ANDROID_JAR" --manifest app/src/main/AndroidManifest.xml --java build/generated build/compiled/resources.zip
find app/src/main/java build/generated -name '*.java' > build/sources.txt
if command -v javac >/dev/null; then
 javac -encoding UTF-8 -source 8 -target 8 -classpath "$ANDROID_JAR" -d build/classes @build/sources.txt
else
 java -jar "${ECJ_JAR:?Set ECJ_JAR when javac is unavailable}" -8 -encoding UTF-8 -bootclasspath "$ANDROID_JAR:$BT/core-lambda-stubs.jar" -d build/classes @build/sources.txt
fi
(cd build/classes && zip -q -r ../classes.jar .)
"$BT/d8" --lib "$ANDROID_JAR" --min-api 26 --output build/dex build/classes.jar
(cd build/dex && zip -q -u ../unsigned.apk classes.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
if [ ! -f build/local.keystore ]; then
 keytool -genkeypair -keystore build/local.keystore -storepass android -keypass android -alias moto -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Moto Theme Local Build' >/dev/null 2>&1
fi
"$BT/apksigner" sign --ks build/local.keystore --ks-pass pass:android --key-pass pass:android --out build/MotoTheme.apk build/aligned.apk
"$BT/apksigner" verify --verbose build/MotoTheme.apk
