# Moto Theme — Android app for Omkar

## Install / इस्तेमाल
1. MotoTheme.apk को Android फोन में खोलें। फोन पूछे तो उस file manager/browser के लिए Install unknown apps की अनुमति दें। यह Play Store release नहीं, locally signed build है।
2. Explore में 288 original procedural designs हैं (12 design families × 24 variations)। डिजाइन खोलकर still या live चुनें। सभी designs offline बनते हैं; इसलिए APK छोटा है।
3. Still में Home, Lock, या दोनों चुनें। Download से HD 1080×1920 या portrait 4K 2160×3840 PNG सेव करें। आपकी screen का वास्तविक resolution अलग हो सकता है।
4. अपनी reel/video पहले फोन में डाउनलोड करें। Import → Add video or photo → फ़ाइल चुनें → preview → Apply as live wallpaper। यह ऐप Instagram से सीधे डाउनलोड नहीं करता।
5. Android preview में Set wallpaper दबाएँ। Home and lock screen विकल्प फोन/Android पर निर्भर है। यदि उपलब्ध नहीं है, ऐप उसे force नहीं कर सकता। वैकल्पिक “Use video frame on lock screen” वीडियो का पहला frame स्थिर lock-screen wallpaper बनाता है।
6. Themes में चार palettes हैं। Preview themed launcher में installed apps के मूल icons के आसपास रंगीन backgrounds मिलते हैं। Choose default home app से इसे वैकल्पिक home launcher बनाएँ। यह दूसरे launchers के icons/system UI को नहीं बदलता। वापस जाने के लिए Android Settings → Apps → Default apps → Home app से अपना पुराना launcher चुनें।

## Features
- 288 seeded original vector/Canvas wallpapers, 12 families; abstract 2D and shaded 3D-style art, not true 3D meshes or photo collections.
- Animated versions, search, family filters, local favorites, HD/4K PNG export through Android file picker.
- Native Android WallpaperService, stops art rendering and pauses video when wallpaper is hidden. Art animation 15 or 30 fps; this setting does not alter video frame rate.
- Offline photo/video import with private local copies; 300 MB limit per file. MP4/H.264 is recommended; actual codec support depends on the phone. GIF is imported as a still image, not an animated wallpaper. Imported photos retain their source detail and are downsampled for memory safety, not AI upscaled.
- Muted looping video with center crop in the wallpaper service, media preview, remove inactive imports, optional first video frame as lock wallpaper.
- Four theme palettes and an optional basic app-grid home launcher. No widgets, folders, gestures, or full icon-pack replacement.
- No internet permission, account, ads, analytics, subscriptions or broad storage access.

## Scope and testing
Independent app, not affiliated with Motorola; does not bundle official Motorola wallpapers or trademarks as artwork. Android 8+ (API 26), target API 34. The exact Moto model does not need to be hardcoded; wallpaper capabilities depend on its Android build.

Compiled against Android API 35 and build tools 35.0.0. APK v2/v3 signatures and manifest/package structure verified. No Android device/emulator was available for runtime testing. Installation, visual layout, codecs, launcher behavior, and home/lock live support still need testing on the phone. This is a first build, not a claim of device-tested production readiness.

Changing the selected live design/video updates any currently active Moto Theme live wallpaper as well as its preview. Canceling the system preview does not restore the previous selected design. To keep an earlier design, select it again in the app. Clearing app data/uninstalling removes imports and favorites.

## Build source
Open this directory in Android Studio and let Gradle sync. Requires Android SDK platform 35, Build Tools 35.0.0, JDK 17, and Gradle 8.9 compatible with Android Gradle Plugin 8.7.3. There is no bundled Gradle wrapper binary. Alternatively, use the dependency-light build:

```bash
ANDROID_SDK_ROOT=/path/to/android-sdk ./build-local.sh
```

This needs javac, java, keytool, zip, and the Android SDK packages listed above. If only a Java runtime exists, set ECJ_JAR to Eclipse ECJ 3.37.0. The local build creates a self-signed testing key in build/local.keystore. Keep the same key for update installs. A newly generated key cannot update an existing installation signed with another key.

## Quick phone checks
- Install and open; browse a design from each family, search, favorite and reopen.
- Export HD/4K and inspect PNG dimensions.
- Apply a still to home, lock and both.
- Apply animated art, lock/unlock, rotate preview where supported, switch apps.
- Import a portrait MP4; preview, apply live, reboot and verify playback. Check a landscape clip's crop. Try an unsupported file and confirm an error is shown.
- Check the Android wallpaper picker for home/lock live availability; try still-frame lock fallback if absent.
- Import a rotated photo, preview/apply; delete inactive media.
- Preview launcher, change palette, launch an app; switch default launcher and switch back.

## Android reference APIs
https://developer.android.com/reference/android/app/WallpaperManager
https://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine
https://developer.android.com/reference/android/content/Intent#ACTION_OPEN_DOCUMENT
