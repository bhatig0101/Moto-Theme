package com.omkar.mototheme;
import android.service.wallpaper.WallpaperService;import android.os.*;import android.graphics.*;import android.view.*;import android.content.*;import android.media.MediaPlayer;
public class LiveWallpaper extends WallpaperService {
 public Engine onCreateEngine(){return new LiveEngine();}
 class LiveEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
  Handler handler=new Handler(Looper.getMainLooper());SharedPreferences prefs;boolean visible=false,surface=false,prepared=false;MediaPlayer player;float offset=0;long start=SystemClock.uptimeMillis();Runnable tick=()->draw();
  public void onCreate(SurfaceHolder h){super.onCreate(h);prefs=getSharedPreferences("moto",0);prefs.registerOnSharedPreferenceChangeListener(this);setTouchEventsEnabled(false);}
  public void onSharedPreferenceChanged(SharedPreferences p,String key){if(key.equals("mode")||key.equals("video")||key.equals("art")){handler.removeCallbacks(reconfigure);handler.post(reconfigure);}}
  Runnable reconfigure=()->configure();
  void release(){prepared=false;if(player!=null){player.release();player=null;}}
  void configure(){handler.removeCallbacks(tick);release();if(!surface)return;if(prefs.getString("mode","art").equals("video")){try{player=new MediaPlayer();MediaPlayer current=player;current.setDataSource(prefs.getString("video",""));current.setSurface(getSurfaceHolder().getSurface());current.setLooping(true);current.setVolume(0,0);current.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);current.setOnPreparedListener(mp->{if(player!=mp)return;prepared=true;if(visible)mp.start();});current.setOnErrorListener((mp,a,b)->{if(player==mp){release();draw();}return true;});current.prepareAsync();}catch(Exception e){release();draw();}}else draw();}
  public void onVisibilityChanged(boolean v){visible=v;handler.removeCallbacks(tick);if(player!=null&&prepared){try{if(v)player.start();else player.pause();}catch(IllegalStateException e){configure();}}else if(v&&player==null)draw();}
  public void onSurfaceCreated(SurfaceHolder h){super.onSurfaceCreated(h);surface=true;configure();}
  public void onSurfaceChanged(SurfaceHolder h,int f,int w,int he){super.onSurfaceChanged(h,f,w,he);if(player==null)draw();}
  public void onSurfaceDestroyed(SurfaceHolder h){surface=false;handler.removeCallbacks(tick);release();super.onSurfaceDestroyed(h);}
  public void onOffsetsChanged(float x,float y,float xs,float ys,int xp,int yp){offset=x-.5f;}
  void draw(){handler.removeCallbacks(tick);if(!visible||!surface||player!=null)return;Canvas c=null;try{c=getSurfaceHolder().lockCanvas();if(c!=null)Art.draw(c,c.getWidth(),c.getHeight(),prefs.getInt("art",0),(SystemClock.uptimeMillis()-start)/1000f,offset);}catch(RuntimeException ignored){}finally{if(c!=null)getSurfaceHolder().unlockCanvasAndPost(c);}handler.postDelayed(tick,prefs.getBoolean("eco",true)?67:33);}
  public void onDestroy(){handler.removeCallbacksAndMessages(null);release();prefs.unregisterOnSharedPreferenceChangeListener(this);super.onDestroy();}
 }
}
