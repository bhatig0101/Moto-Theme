package com.omkar.mototheme;
import android.graphics.*;
import java.util.Random;
public final class Art {
 public static final int COUNT=288;
 public static final String[] FAMILIES={"Silk","Orbit 3D","Dunes","Aurora","Prism 3D","Ripple","Peaks","Cosmos","Bloom","Neon","Paper","Ocean"};
 public static String name(int id){return FAMILIES[id/24]+" "+String.format(java.util.Locale.US,"%02d",id%24+1);}
 public static int color(int id,float shift,float value){return Color.HSVToColor(new float[]{(id*37.71f+shift)%360,.65f,value});}
 public static Bitmap bitmap(int id,int w,int h){Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);draw(new Canvas(b),w,h,id,0,0);return b;}
 public static void draw(Canvas c,int w,int h,int id,float time,float offset){
  c.save();c.scale(w/360f,h/720f);int a=color(id,0,.85f),b=color(id,65,.45f);Paint p=new Paint(3);p.setShader(new LinearGradient(0,0,360,720,new int[]{0xff070a16,b,0xff070c1c},null,Shader.TileMode.CLAMP));c.drawRect(0,0,360,720,p);p.setShader(null);
  Random r=new Random(id*7919L+42);float t=time*.25f; c.translate(offset*12,0);
  switch(id/24){
   case 0:case 3:case 11:
    for(int k=0;k<20;k++){Path path=new Path();float y=130+k*23;path.moveTo(-50,y);path.cubicTo(80,y-190+(float)Math.sin(t+k*.15)*60,220,y+220,420,y-50);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6+k*.7f);p.setColor(color(id,k*4,.5f+k*.02f));p.setAlpha(150);c.drawPath(path,p);}break;
   case 1:
    for(int k=0;k<9;k++){float x=40+r.nextFloat()*280,y=100+r.nextFloat()*540,rad=22+r.nextFloat()*65; x+=(float)Math.sin(t+k)*15;y+=(float)Math.cos(t+k)*14;p.setShader(new RadialGradient(x-rad*.35f,y-rad*.4f,rad*1.5f,new int[]{0xfff0ffff,color(id,k*12,.9f),0xff0a1021},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,rad,p);}p.setShader(null);break;
   case 2:case 6:case 10:
    for(int k=0;k<8;k++){float y=190+k*75;Path q=new Path();q.moveTo(-30,760);q.lineTo(-30,y);for(int x=-30;x<=420;x+=45){float yy=y-r.nextFloat()*130+(float)Math.sin(t+k)*7;if(id/24==2)q.quadTo(x-22,yy-30,x,yy);else q.lineTo(x,yy);}q.lineTo(420,760);q.close();p.setColor(color(id,k*8,.35f+k*.08f));c.drawPath(q,p);}break;
   case 4:
    for(int k=0;k<16;k++){float x=r.nextFloat()*360,y=90+r.nextFloat()*600,s=20+r.nextFloat()*50; c.save();c.translate(x,y);c.rotate(k*23+time*4);Path q=new Path();q.moveTo(0,-s);q.lineTo(s,0);q.lineTo(0,s);q.lineTo(-s,0);q.close();p.setColor(color(id,k*7,.85f));c.drawPath(q,p);q.reset();q.moveTo(0,-s);q.lineTo(s,0);q.lineTo(0,s);q.close();p.setColor(color(id,k*7,.45f));c.drawPath(q,p);c.restore();}break;
   case 5:
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);for(int k=0;k<24;k++){p.setColor(color(id,k*5,.85f));p.setAlpha(220-k*6);c.drawOval(new RectF(180-k*15-(float)Math.sin(t)*10,330-k*20,180+k*15+(float)Math.sin(t)*10,390+k*20),p);}break;
   case 7:
    for(int k=0;k<170;k++){float x=r.nextFloat()*360,y=(r.nextFloat()*720+time*(2+k%5))%720;p.setColor(Color.WHITE);p.setAlpha(60+r.nextInt(180));c.drawCircle(x,y,.5f+r.nextFloat()*1.4f,p);}p.setAlpha(255);p.setShader(new RadialGradient(155,280,110,new int[]{color(id,35,1),a,0xff080c18},null,Shader.TileMode.CLAMP));c.drawCircle(180,310,95,p);p.setShader(null);break;
   case 8:
    c.save();c.translate(180,350);c.rotate(time*3);for(int k=0;k<36;k++){c.rotate(10);p.setColor(color(id,k*3,.85f));p.setAlpha(95);c.drawOval(new RectF(-35,-190,35,35),p);}c.restore();break;
   case 9:
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);for(int k=0;k<18;k++){c.save();c.rotate(k*3+(float)Math.sin(t)*8,180,360);p.setColor(color(id,k*9,1));c.drawRoundRect(new RectF(35+k*6,170+k*9,325-k*6,550-k*9),20,20,p);c.restore();}break;
  }
  c.restore();
 }
}
